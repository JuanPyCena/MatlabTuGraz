clear all;
close all;
clc

%% General Values

% Physical Parameter of the Earth
G       = 6.674e-11;
omega_N = 7.2921151467064e-15;
GM_sun  = 1.32712442076e20;
GM_moon = 4.9027779e12;

% Geodetic Parameters of the Earth
M  = 5.9737e24;
R  = 6378136.6;
A  = 0.3296108 * M * R * R;
B  = 0.3296108 * M * R * R;
C  = 0.3307007 * M * R * R;
tr = A + B + C;

% Lovenumbers
k_re = 0.3077;
k_im = 0.0036;

% Coefficients for Matrices
coefficient_T_g = sqrt(5/3) * M * R * R;
coefficient_T_r = (omega_N * R^5) / (3 * G);
coefficient_F   = (omega_N * omega_N * R^5) / (3 * G);


%% Feeding in data
AAM_FILE = 'ESMGFZ_AAM_v1.0_03h_2004.asc';
HAM_FILE = 'ESMGFZ_HAM_v1.2_24h_2004.asc';
OAM_FILE = 'ESMGFZ_OAM_v1.0_03h_2004.asc';

AOHIS_FILE = 'potentialCoefficientsAOHIS.txt';
TIDE_FILE  = 'potentialCoefficientsTides.txt';

% To get another set of data for the calculation change the file names. The
% sample rate will be adapted automatically
[timespan, h, grav_potent,r_moon,r_sun, reference] = read_data(OAM_FILE, TIDE_FILE);
initial = reference(:,1);
c_20 = grav_potent(1, :);
c_21 = grav_potent(2, :);
s_21 = grav_potent(3, :);
c_22 = grav_potent(4, :);
s_22 = grav_potent(5, :);


%% Creating Matrices

% Moments from moon and sun
dist_sun = sqrt(r_sun(1,:).^2 + r_sun(2,:).^2 + r_sun(3,:).^2);
M_sun(1,:) = (((C-B) .* r_sun(2,:) .* r_sun(3,:)) ./ (dist_sun.^5)) .* (3 * GM_sun);
M_sun(2,:) = (((A-C) .* r_sun(1,:) .* r_sun(3,:)) ./ (dist_sun.^5)) .* (3 * GM_sun);
M_sun(3,:) = (((B-A) .* r_sun(1,:) .* r_sun(2,:)) ./ (dist_sun.^5)) .* (3 * GM_sun);

dist_moon = sqrt(r_moon(1,:).^2 + r_moon(2,:).^2 + r_moon(3,:).^2);
M_moon(1,:) = (((C-B) .* r_moon(2,:) .* r_moon(3,:)) ./ (dist_moon.^5)) .* (3 * GM_moon);
M_moon(2,:) = (((A-C) .* r_moon(1,:) .* r_moon(3,:)) ./ (dist_moon.^5)) .* (3 * GM_moon);
M_moon(3,:) = (((B-A) .* r_moon(1,:) .* r_moon(2,:)) ./ (dist_moon.^5)) .* (3 * GM_moon);

M = M_sun + M_moon;

% T_g - this will be separated into 3 3x1 vectors to enable the usage of
% the ode45 later. The 3 column vector are then parsed into a matrix again,
% but for a time variant matrix this is the easiest way
T_g_c1 = coefficient_T_g .* [((1/sqrt(3)) .* c_20 - c_22); -s_22; -c_21];
T_g_c2 = coefficient_T_g .* [-s_22; (1/sqrt(3)) .* c_20 + c_22; -s_21];
T_g_c3 = coefficient_T_g .* [-c_21; -s_21; -(2/sqrt(3)) .* c_20];

T_g_c1(1,:) = T_g_c1(1,:) + tr/3;
T_g_c2(2,:) = T_g_c2(2,:) + tr/3;
T_g_c3(3,:) = T_g_c3(3,:) + tr/3;

% T_g_c1 = zeros(3,timespan);
% T_g_c2 = zeros(3,timespan);
% T_g_c3 = zeros(3,timespan);
% 
% T_g_c1(1,:) = tr/3;
% T_g_c2(2,:) = tr/3;
% T_g_c3(3,:) = tr/3;

% F_reduce - this is the F-Matrix withouth the influence of the T tensor.
F_reduced = coefficient_F .* [k_re, k_im, 0;
                             -k_im, k_re, 0;
                              0   ,  0  , 0];

%% Calculation

[T, W] = ode45(@(t,w) EL_DGL(t, w, F_reduced, T_g_c1, T_g_c2, T_g_c3, M, h, coefficient_T_r, k_re, k_im),... % Differential Equation
                             1:1:(timespan-1),... % timespan
                             initial); % initial w

% Results: angular velocities, pole positions and changed of Length of Day
results   = W';
errors    = reference(:,1:(timespan-1)) - results;
xp        = (R/omega_N) .* results(1,:);
yp        = (R/omega_N) .* results(2,:);
delta_LOD = (86400/omega_N).*(omega_N - results(3,:));
reference_LOD = (86400).*((omega_N - reference(3,:))/omega_N);

% Reference pole positions
xp_reference = (R/omega_N) .* reference(1,:);
yp_reference = (R/omega_N) .* reference(2,:);
 
%% Plot
figure(1)
subplot(5,1,1);
plot(T, results(1,:));
subplot(5,1,2);
plot(T, results(2,:));
subplot(5,1,3);
plot(T, results(3,:));
subplot(5,1,4);
plot(T, errors(1,:));

figure(2)
plot(xp,yp);

figure(3)
plot(delta_LOD);


