function [timespan, h, grav_potent,r_moon,r_sun, reference] = read_data(fileName_motionMomentum, fileName_gravPotent)
% This function reads in a series of given files and then returns the
% timespan, motion terms of the angular momentum, gravitational potential,
% and the positions of the moon and sun. 

    % General constants
    M = 5.9737e24;
    R = 6378136.6;
    A = 0.3296108 * M * R * R;
    B = 0.3296108 * M * R * R;
    C = 0.3307007 * M * R * R;
    omega_N = 7.2921151467064e-15;

    % importing the data
    delimiterIn = ' ';
    
    DATA_motionMomentum = importdata(fileName_motionMomentum, delimiterIn);
    DATA_gravPotential  = importdata(fileName_gravPotent, delimiterIn);
    DATA_moon           = importdata('moon.txt', delimiterIn);
    DATA_sun            = importdata('sun.txt', delimiterIn);
    DATA_reference      = importdata('earthRotationVector.txt', delimiterIn);
    
    % allocating the timespan
    timespan = length(DATA_motionMomentum(:,1));
    
    % allocating the motionMomentum
    h(1,:) = DATA_motionMomentum(:,9)  .* (omega_N * (C - A) / (1.610));
    h(2,:) = DATA_motionMomentum(:,10) .* (omega_N * (C - A) / (1.610));
    h(3,:) = DATA_motionMomentum(:,11) .* (omega_N * C / (1.125));
    
    % defining the timestep by checking the fileName
    if ~isempty(strfind(fileName_motionMomentum, '_24h_'))
        step = 24
    elseif ~isempty(strfind(fileName_motionMomentum, '_03h_'))
        step = 3
    else
        step = 1
    end
    
    % allocating the gravitational potential
    grav_potent(1,:) = DATA_gravPotential(1:step:(step * timespan),2);
    grav_potent(2,:) = DATA_gravPotential(1:step:(step * timespan),3);
    grav_potent(3,:) = DATA_gravPotential(1:step:(step * timespan),4);
    grav_potent(4,:) = DATA_gravPotential(1:step:(step * timespan),5);
    grav_potent(5,:) = DATA_gravPotential(1:step:(step * timespan),6);
    
    % allocation of the moon's and the sun's coordinates
    r_moon(1,:) = DATA_moon(1:step:(step * timespan),2);
    r_moon(2,:) = DATA_moon(1:step:(step * timespan),3);
    r_moon(3,:) = DATA_moon(1:step:(step * timespan),4);
    
    r_sun(1,:) = DATA_sun(1:step:(step * timespan),2);
    r_sun(2,:) = DATA_sun(1:step:(step * timespan),3);
    r_sun(3,:) = DATA_sun(1:step:(step * timespan),4);
    
    % allocating the reference data
    reference(1,:) = DATA_reference(1:step:(step * timespan),2);
    reference(2,:) = DATA_reference(1:step:(step * timespan),3);
    reference(3,:) = DATA_reference(1:step:(step * timespan),4);
end

