function w_dot = EL_DGL(t, w, F_reduced, T_g_c1, T_g_c2, T_g_c3, M, h, coefficient_T_r, k_re, k_im)
    % just making sure, that the index for the matrices is always an integer.
    % Since the timestep is not fixed, this is the only way to provide this                               
    t = floor(t); 
    
    % getting the angular velocity to construct the T_r matrix
    w_x = w(1);
    w_y = w(2);
    
    % Parsing the T_g matrix from its column vector by index
    T_g  = [T_g_c1(:,t) , T_g_c2(:,t), T_g_c3(:,t)];
    
    % Manual derivative
    dT_g = [T_g_c1(:,t + 1) , T_g_c2(:,t + 1), T_g_c3(:,t + 1)] - [T_g_c1(:,t) , T_g_c2(:,t), T_g_c3(:,t)];
    dT_g = 0;
    
    % constructing T_r using the love number and the angular velocity
    T_r  = coefficient_T_r .* [0, 0, k_re * w_x + k_im * w_y;
                               0, 0, k_re * w_y - k_im * w_x;
                               k_re * w_x + k_im * w_y, k_re * w_y - k_im * w_x 0];
                           
    % construction the final inertia tensor                        
    T = T_g + T_r;
    T = eye(3);
    
    % The F matrix constists of a part that is dependet of the angular
    % velocity and a part that is independet. These two parts are added
    % here
    F = T + F_reduced;
    
    % Manual derivative
    dh = h(:,t + 1) - h(:,t);
    
    % The differential equation
    w_dot = F\(M(:,t) - dT_g * w - cross(w, T * w) - cross(w, h(:,t)) - dh);
end

